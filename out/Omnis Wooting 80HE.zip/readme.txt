made by omni
dont steal for cookie
inspired by Z E P T O <3
