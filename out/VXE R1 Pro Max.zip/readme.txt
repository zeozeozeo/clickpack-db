Mouse: VXE (aka VGN) R1 Pro Max (Kailh White Sword switches)
Includes: clicks (12), releases (12), softclicks (25), softreleases (25), hardclicks (11), hardreleases (11) + noise file, 97 sounds in total
Credit: zeo (fluffyzeo on discord)
