  This bundle includes the clicks from Bo. Due to white noise, after post processing make sure to include a white noise file. You can find one on this zip, it's named "white_noise.wav", and also include the level's music. This will make it sound way more legit than it does currently, due to white noise fucking us over.
  CHANGELOG:
- Alpha v0.1.0: Added soft clicks.
- Alpha v0.2.0: Fixed soft clicks. Now they're way better and actually usable.
  Bundle made by Doki and Naxio, enjoy! ;)