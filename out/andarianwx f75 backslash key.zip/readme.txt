ANDARIAN'S F75 BACKSLASH KEY

pros:
- realistic
- good at spam
- "realistic" releasing sounds
- expanded from private version to ~100 sounds
- has noise (RECOMMENDED)
cons:
- a bunch of static noise
- can be noticeably "unstable" with lower game volume
worthy for best: no, the cuts are terrible

USING NOISE IS RECOMMENDED! AND ALWAYS ENABLE MUSIC VOLUME

KEYBOARD: Aula F75 (south facing PCB):
-Layout: 75% layout with 80 or 81 keys.
-Mounting: Gasket-mounted for a cushioned feel.
-Hot-Swappable: Supports 3-pin and 5-pin switches.
-Connectivity: Tri-mode (Wireless 2.4G, Bluetooth, Wired Type-C).
-Battery: 4000mAh Lithium battery.
-Keycaps: PBT material, often with side-printed legends.
-Lighting: South-facing RGB (16.8 million colors).
-Structure: 5-layer internal foam for sound dampening.
-Weight: Approximately 1023g.
-Dimensions: Approximately 

SWITCHES: Pre-lubed Leobog Reaper (linear) or Graywood V3.
-Switch Type: Linear
-Actuation Force: 45±3gf
-Bottom-out Force: 55±3gf
-Actuation Travel: 1.8±0.3mm
-Total Travel: 3.6±0.3mm
-Factory Lubed: Yes
-Material: POM Stem, PC Top & Nylon Bottom Housing
-Pin: 5-pin
-Lifespan: 60 million strokes
-Compatibility: MX structure