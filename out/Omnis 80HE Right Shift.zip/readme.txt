made by omni
no steal for cookie
inspired by Z E P T O <3
