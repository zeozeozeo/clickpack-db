My biggest clickpack EVER
uh
Gen-2 Razer analog optical switches
yes deskmat
carbon fiber desk
made in packmak because i'm too lazy to manually cut
best clickpacks i beg
