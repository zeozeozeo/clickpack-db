USING NOISE IS RECOMMENDED!

KEYBOARD: SayoDevice O3C
SWITCHES: GATERON MAGNETIC JADE PRO
-Switch Type: Linear Hall Effect (Magnetic)
-Initial Force: 36±5gf (some sources list 36±7gf)
-Bottom-out Force: 50±10gf
-Total Travel: 3.5±0.1mm
-Actuation Range: Customizable (0.1mm - 3.3mm)
-Lifespan: Over 100 million keystrokes
-Lubrication: Factory Pre-lubed
-Lighting: Upgraded 3.0 LED diffuser (brighter/softer diffusion)
-Material: POM Stem, PA66 Bottom, PC Top