ANDARIAN'S UPDATED SAYO CLICKPACK (V6 - APRIL 2026 VERSION)
pros:
- realistic probably
- its manually cut, i carefully cut each sounds
- sounds very good
- i recorded sound for 2p but i dont have time to cut it
- has noise
cons:
- it's another sayo clickpack
changes i made from my last clickpacks:
- buffed noise volume at 1.0 volume settings
- cut manually using audacity
- audacity denoiser is now more carefully used
- hopefully changed how it sounds by adjusting the room enviroment
worthy for best: i will tell in discord

USING NOISE IS RECOMMENDED!

for more specs, check "andarianwx sayo deskmat v2026.4.4.1" on clickpackdb (the readme)