"uylas clicks"

this clickpack was made using my up arrow key on my wooting 80he

basically what my exact clicks sound like when i play

my wooting 80he:
ABS plastic case
double shot pbt keycaps
ws flux pink lotus switch

pros:
realistic sounding
low background noise
clacky


cons:
metallic sounding (personally dont like this but maybe someone does)


idk what other things to list so this is kind of some ahh pros and cons