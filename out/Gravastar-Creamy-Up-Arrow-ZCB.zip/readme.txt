Gravastar Creamy Up Arrow

On deskmat on marble desk.

Built with CutItQuik for ZCB Live.

Install
  1. Unzip this archive.
  2. Move the resulting folder into the .zcb/clickpacks folder next to your
     Geometry Dash executable.
  3. In ZCB Live, open Clickpack > Select clickpack and pick it from the list.

Layout: Full platformer (player1, player2, left1, right1, left2, right2)
Format: 48 kHz, mono, 16-bit PCM WAV. No manifest is needed; ZCB reads the
folder name as the pack name.
