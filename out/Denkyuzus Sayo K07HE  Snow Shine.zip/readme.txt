Basically an clickpack with my equipment recorded. Nothing too special.

Keypad: SayoDevice K07HE
Switches: Unionwell Snow Shine
Microphone: Maono DM40 Pro

All of the wave files were processed through Browser Noise Suppresion or post-denoiser.

ALSO COMING TO LOCAL ECHO DATABASE NEAR YOUR HOUSE!


youtube.com/@d3nkyu2uGD
youtube.com/@дыхХх
twitter.com/denkyuzuGD
t.me/dbix_gd