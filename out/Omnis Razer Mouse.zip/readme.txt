made by omni
manually cut
inspired by Z E P T O
dont steal and earn a cookie