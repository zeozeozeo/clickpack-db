Clicks recorded by @thebestfriendmax
Cut by @fluffyzeo
