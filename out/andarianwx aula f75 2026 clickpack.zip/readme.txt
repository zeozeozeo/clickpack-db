keyboard: aula f75 (south facing pcb)
switches:
- up arrow: leobog reaper linear (stock)
- p2 (` key): mmd princess tactile (lubed)
mods:
- tape mod
- lubed switches
- lubed and modded stabs