Keyboard full name: Razer Huntsman V3 Pro TKL
Case: premium 5052 brushed aluminum alloy top plate with a hardened plastic bottom chassis
uses a mousepad
Gen-2 Razer Analog Optical Switches
i dont know if you need to know this but
Desk: Bestier 52 in. L-Shaped Black Fiber Carbon LED Gaming Desk with Storage Shelf and Power Outlets
thats about it
enjoy