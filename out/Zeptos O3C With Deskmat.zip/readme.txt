made for the goat zcb
fun
realistic i think
2nd clickpack ever
